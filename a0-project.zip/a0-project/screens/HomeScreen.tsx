import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet } from 'react-native';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';

export default function MathQuizCalculator() {
  const [firstNumber, setFirstNumber] = useState('');
  const [secondNumber, setSecondNumber] = useState('');
  const [operation, setOperation] = useState('');
  const [userAnswer, setUserAnswer] = useState('');
  const [feedback, setFeedback] = useState('');
  const [showAnswer, setShowAnswer] = useState(false);

  const calculateCorrectAnswer = () => {
    const num1 = parseFloat(firstNumber);
    const num2 = parseFloat(secondNumber);
    
    switch(operation) {
      case '+': return num1 + num2;
      case '-': return num1 - num2;
      case '×': return num1 * num2;
      case '÷': return num1 / num2;
      default: return null;
    }
  };

  const checkAnswer = () => {
    if (!firstNumber || !secondNumber || !operation || !userAnswer) {
      setFeedback('Please fill in all fields');
      return;
    }

    const correctAnswer = calculateCorrectAnswer();
    const userNum = parseFloat(userAnswer);

    if (Math.abs(userNum - correctAnswer) < 0.001) {
      setFeedback('Correct! 🎉');
      setShowAnswer(false);
    } else {
      setFeedback('Wrong!');
      setShowAnswer(true);
    }
  };

  const resetCalculator = () => {
    setFirstNumber('');
    setSecondNumber('');
    setOperation('');
    setUserAnswer('');
    setFeedback('');
    setShowAnswer(false);
  };

  const operations = ['+', '-', '×', '÷'];

  return (
    <LinearGradient
      colors={['#4c669f', '#3b5998', '#192f6a']}
      style={styles.container}
    >
      <View style={styles.card}>
        <Text style={styles.title}>Math Quiz Calculator</Text>
        
        <View style={styles.inputContainer}>
          <TextInput
            style={styles.input}
            value={firstNumber}
            onChangeText={setFirstNumber}
            keyboardType="numeric"
            placeholder="First number"
            placeholderTextColor="#666"
          />
          
          <View style={styles.operationsContainer}>
            {operations.map((op) => (
              <TouchableOpacity
                key={op}
                style={[
                  styles.operationButton,
                  operation === op && styles.selectedOperation,
                ]}
                onPress={() => setOperation(op)}
              >
                <Text style={[
                  styles.operationText,
                  operation === op && styles.selectedOperationText
                ]}>{op}</Text>
              </TouchableOpacity>
            ))}
          </View>

          <TextInput
            style={styles.input}
            value={secondNumber}
            onChangeText={setSecondNumber}
            keyboardType="numeric"
            placeholder="Second number"
            placeholderTextColor="#666"
          />
        </View>

        <View style={styles.answerContainer}>
          <Text style={styles.label}>Your Answer:</Text>
          <TextInput
            style={styles.answerInput}
            value={userAnswer}
            onChangeText={setUserAnswer}
            keyboardType="numeric"
            placeholder="Enter your answer"
            placeholderTextColor="#666"
          />
        </View>

        <View style={styles.buttonContainer}>
          <TouchableOpacity
            style={styles.checkButton}
            onPress={checkAnswer}
          >
            <MaterialCommunityIcons name="check-circle" size={24} color="white" />
            <Text style={styles.buttonText}>Check Answer</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.resetButton}
            onPress={resetCalculator}
          >
            <MaterialCommunityIcons name="refresh" size={24} color="white" />
            <Text style={styles.buttonText}>Reset</Text>
          </TouchableOpacity>
        </View>

        {feedback && (
          <View style={styles.feedbackContainer}>
            <Text style={[
              styles.feedback,
              feedback === 'Correct! 🎉' ? styles.correctFeedback : styles.wrongFeedback
            ]}>
              {feedback}
            </Text>
            {showAnswer && (
              <Text style={styles.correctAnswer}>
                The correct answer is: {calculateCorrectAnswer()}
              </Text>
            )}
          </View>
        )}
      </View>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    justifyContent: 'center',
  },
  card: {
    backgroundColor: 'white',
    borderRadius: 20,
    padding: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 5,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    textAlign: 'center',
    color: '#333',
    marginBottom: 20,
  },
  inputContainer: {
    marginBottom: 20,
  },
  input: {
    backgroundColor: '#f5f5f5',
    borderRadius: 10,
    padding: 15,
    fontSize: 18,
    marginBottom: 10,
    color: '#333',
  },
  operationsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    marginVertical: 10,
  },
  operationButton: {
    width: 50,
    height: 50,
    borderRadius: 25,
    backgroundColor: '#f0f0f0',
    justifyContent: 'center',
    alignItems: 'center',
  },
  selectedOperation: {
    backgroundColor: '#4c669f',
  },
  operationText: {
    fontSize: 24,
    color: '#333',
  },
  selectedOperationText: {
    color: 'white',
  },
  answerContainer: {
    marginBottom: 20,
  },
  label: {
    fontSize: 16,
    color: '#666',
    marginBottom: 5,
  },
  answerInput: {
    backgroundColor: '#f5f5f5',
    borderRadius: 10,
    padding: 15,
    fontSize: 18,
    color: '#333',
  },
  buttonContainer: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    marginBottom: 20,
  },
  checkButton: {
    backgroundColor: '#4CAF50',
    flexDirection: 'row',
    alignItems: 'center',
    padding: 15,
    borderRadius: 10,
    minWidth: 150,
    justifyContent: 'center',
  },
  resetButton: {
    backgroundColor: '#f44336',
    flexDirection: 'row',
    alignItems: 'center',
    padding: 15,
    borderRadius: 10,
    minWidth: 150,
    justifyContent: 'center',
  },
  buttonText: {
    color: 'white',
    fontSize: 16,
    marginLeft: 8,
  },
  feedbackContainer: {
    alignItems: 'center',
  },
  feedback: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 5,
  },
  correctFeedback: {
    color: '#4CAF50',
  },
  wrongFeedback: {
    color: '#f44336',
  },
  correctAnswer: {
    fontSize: 16,
    color: '#666',
  },
});